#pragma once
#include <string>
#include <iostream>


/*            GameObj
            /       \
      Character     Hurting
     /        \   /       \
Player        Boss         Bomb


GameObject - dowolny obiekt gry  
Character - obiekt gry - postac - ma swoje HP
Hurting - obiekt gry ktory jest cechą - nie jest postacią - cechy niszczenia
Player - dziedziczy po charakterze bo jest też postacią ale bardziej ssprecyzowaną
Bomb - dziedziczy po Hutring bo ma cechy tylko i wylacznie nieszczenia
Boss - ma zrówno swoje HP jak i cechy niszczenia dlatego dziedziczy po Hurting i Character
*/

/*@brief klasa zawierające informacje o liczbie HP*/
class HP{
  public:
  /*@brief konstruktor wpisujacy liczbe HP*/
    HP (const int k);
  /*@brief metoda zwracająca liczbe HP */
    std::string getHP()const;
    
  private:
    int _k; //HP
};

/*@brief klasa dowolnego obiektu gry*/
class GameObj{
  public:
  /*@brief konstruktor wpisujacy id number */
    GameObj(std::string id);
  /*@brief metoda virtualna printująca dowoly obiekt klasy, pozniej przykrywana  przez metody klas pochodnych*/
    virtual void print()const=0;
  /*@brief metoda zwracająca numer id jako string*/
    std::string id()const;
  /*@brief virtualny destruktor*/
    virtual ~GameObj()=default;
  protected:
    std::string _id;
};

std::ostream &operator<<(std::ostream &s,const GameObj &ob);

/*@brief klasa */
class Character: public virtual GameObj{
  public:
  /*@brief konstruktor wpisujacy nazwe postaci oraz jej HP*/
    Character(HP h,std::string name,std::string id);
  /*@brief metoda zwracająca ilosć HP*/
    std::string hp()const; 
  protected:
    std::string _name;
    HP _h;
};

/*@brief klasa */
class Player:public virtual Character{
  public:
  /*@brief konsrtuktor wywolujacy w tablicy inicjalizacyjnej konstruktor klas wyżsczych*/
    Player(HP h,std::string name,std::string id);
  /*@brief metoda printująca dane o playerze, przykrywajaca metode z klasy bazowej*/
    void print()const override;
};

/*@brief klasa */
class Hurting:public virtual GameObj{
  public:
  /*@brief konstruktor wpisujący HP ataku*/
    Hurting(HP h,std::string id);
  /*@brief  metoda printująca dane o Hurtingu, przykrywajaca metode z klasy bazowej*/
    void print()const override;
  /*@brief metoda zwracająca ilosć HP ataku*/
    std::string hp()const;
  protected:
    HP _attackHP;
};

/*@brief klasa */
class Bomb:public virtual Hurting{
  public:
  /*@brief konstruktor klasy Bomb, w tablicy inicjalizaycjnej wywolywane sa kosntruktory klas wyzsczych*/
    Bomb(HP h,std::string id);
};

/*@brief klasa */
class Boss:public virtual Character,public virtual Hurting{
  public:
  /*@brief konstruktor klasy Boss, w tablicy inicjalizaycjnej wywolywane sa kosntruktory klas wyzsczych*/
    Boss(HP h, std::string name, HP attackHP, std::string id);
  /*@brief  metoda printująca dane o Bossie, przykrywajaca metode z klasy bazowej oraz wywolująca print Hurtinga*/
    void print()const override;
};