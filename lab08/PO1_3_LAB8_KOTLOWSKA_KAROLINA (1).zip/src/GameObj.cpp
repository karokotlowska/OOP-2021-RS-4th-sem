#include "../include/GameObj.h"


HP::HP (const int k):_k(k){}

std::string HP::getHP()const{
  std::string k=" [";
  k.append(std::to_string(_k));
  k.append(" HP]");
  return k;
}

GameObj::GameObj(std::string id):_id(id){}

std::string GameObj::id()const{
  return _id;
}


Character::Character(HP h,std::string name,std::string id):GameObj(id),_name(name),_h(h){}

std::string Character::hp()const{
  return _h.getHP();
}

Player::Player(HP h,std::string name,std::string id):GameObj(id),Character(h,name,id){}

void Player::print()const{
  std::cout<<"Player "<<_name<<", ma:"<<_h.getHP();
}

std::ostream &operator<<(std::ostream &s,const GameObj &ob){
  ob.print();
  return s;
}

Hurting::Hurting(HP h,std::string id):GameObj(id),_attackHP(h){}

void Hurting::print()const{
  std::cout<<"Jego uderzenie odbiera:"<<_attackHP.getHP();
}

std::string Hurting::hp()const{
  return _attackHP.getHP();
}


Bomb::Bomb(HP h,std::string id):GameObj(id),Hurting(h,id){}


Boss::Boss(HP h, std::string name, HP attackHP, std::string id):GameObj(id),Character(h,name,id),Hurting(attackHP,id){}

void Boss::print()const {
  std::cout<<"Bad guy: "<<_name<<", ma:"<<_h.getHP()<<"\n";
  (static_cast<Hurting>(*this)).print();
}