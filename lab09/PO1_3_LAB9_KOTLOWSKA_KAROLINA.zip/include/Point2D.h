#pragma once

/*klasa przrechowująca informacje o wspolrzednych punktu i jego odleglosci od srodka ukl. wsp.*/
class Point2D{
  public:
  /*@brief konstruktor lokujący wspolrzedne x,y punktu
  @param x - jedna wspolrzedna
  @param y - druga wspolrzedna
  */
    Point2D(const double x, const double y);

  /*@brief operator < ktory umozliwia możliwość porównywania punktów na podstawie odległości od środka układu współrzędnych
  @param p1 punkt ktorego odleglosc ma byc porownywana z punktem na ktorym dziala metoda
  @return zwraca 1 gdy odleglosc punktu na ktorym jest wykonywana metoda jest mniejsza niz odleglosc dla p1
  */
    bool operator<(const Point2D &p1)const;

  /*@brief metoda printująca wspolrzedne punktu i odleglosc*/  
    void Print()const;

  /*@brief metoda zwracająca wspolrzedna x punktu
  @return zwraca wspolrzedna punktu x*/  
    double getx()const;

  /*@brief metoda zwracająca wspolrzedna y punktu
  @return zwraca wspolrzedna punktu y*/    
    double gety()const;

  /*@brief metoda zwracająca odleglosc od srodka ukladu
  @return zwracaodleglosc od srodka ukladu*/  
    double getDistance()const;

  /*@brief metoda statyczna printująca wspolrzedna y punktu
  @param p1 - punkt, ktorego wpspolrzedna y ma byc wyprintowana*/
    static void FunctionPrintY(const Point2D &p1);

  /*@brief metoda statyczna printująca wspolrzedne punktu p1
  @param p1 - punkt, ktorego wpolrzedne maja być wyprintowane*/
    static void PrintPoint(const Point2D &p1);
  private:
    double _x=0.;
    double _y=0.;
    double _distance=0.;
};

/*@brief klasa - funktor służąca jako comparator (klasa tutaj jest funktorem bo ma operator())*/
class OrderAscX{
  public:
  /*@brief comparator
  @param p1 - referencja na obiekt ktory ma byc porownywany
  @param p2 - referencja na obiekt ktory ma byc porownywany
  @return zwraca prawdę jesli pierwsazy element porowynywany jest wiekszy od drugiego*/
    bool operator()(const Point2D &p1,const Point2D &p2);
}; 

/*@brief klasa - funktor służąca jako comparator (klasa tutaj jest funktorem bo ma operator())*/
class OrderDescY{
  public:
  /*@brief comparator
  @param p1 - referencja na obiekt ktory ma byc porownywany
  @param p2 - referencja na obiekt ktory ma byc porownywany
  @return zwraca prawdę jesli pierwsazy element porowynywany jest wiekszy od drugiego*/
    bool operator()(const Point2D &p1,const Point2D &p2);
};

/*@brief funkcja - comparator, zwraca prawde jesli max pierwszego punktu jest mniejszy od max drugiego punktu
 @param p1 - referencja na obiekt ktory ma byc porownywany
@param p2 - referencja na obiekt ktory ma byc porownywany
@return zwraca prawde jesli max pierwszego punktu jest mniejszy od max drugiego punktu
*/
bool MaxDistanceAsc(const Point2D &p1, const Point2D &p2);

/*@brief funkcja printująca wspolrzedną punktu x
@param p1 - referencja na obiekt ktorego wspolrzedna ma byc wypisywana*/
void FunctionPrintX(const Point2D &p1);







