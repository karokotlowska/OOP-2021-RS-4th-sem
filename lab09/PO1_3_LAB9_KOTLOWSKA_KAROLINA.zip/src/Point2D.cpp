#include "../include/Point2D.h"
#include <iostream>
#include <cmath>


Point2D::Point2D(const double x, const double y):_x(x),_y(y),_distance(sqrt(_x*_x+_y*_y)){}

bool Point2D::operator<(const Point2D &p1)const{
  return _distance<p1._distance;
}

void Point2D::Print()const{
  std::cout<<"Point coordinates ("<<getx()<<", "<<gety()<<") distance from origin: "<<getDistance()<<"\n";
}

double Point2D::getx()const{
  return _x;
}

double Point2D::gety()const{
  return _y;
}

double Point2D::getDistance()const{
  return _distance;
}

void  Point2D::FunctionPrintY(const Point2D &p1){
  std::cout<<"Function print y="<<p1.gety()<<"\n";
}

void Point2D::PrintPoint(const Point2D &p1){
  p1.Print();
}

bool OrderAscX::operator()(const Point2D &p1,const Point2D &p2){
  return p1.getx()<p2.getx();
}

bool OrderDescY::operator()(const Point2D &p1,const Point2D &p2){
  return p1.gety()>p2.gety(); 
}

bool MaxDistanceAsc(const Point2D &p1, const Point2D &p2){
  double first=std::max(p1.getx(),p1.gety());
  double second=std::max(p2.getx(),p2.gety());
  if (first<second) return 1;
  else return 0;
}

void FunctionPrintX(const Point2D &p1){
  std::cout<<"Function print x="<<p1.getx()<<"\n";
}

