#pragma once
#include <string>
#include <vector>

/*klasa przechowująca dane o dacie: dzien tygodnia oraz vektor doubli*/
class Data{
public:
/*@brief kontruktor klasy Data, lokuje string i wektor*/
  Data(const std::string str,const std::vector<double> vec);

  /*@brief metoda printująca dane czyli string i wektor doubli, uzywająca pomocniczej funkcji printData*/
  void print()const;

  /*@brief metoda zwracająca wektor _vec
  @return zwraca wetkror _vec*/
  std::vector<double> getVector()const;
private:
  std::string _str;
  std::vector<double> _vec;
};

/*@brief funkcja pomocnicza printująca poszczegolne dane z wektora, uzywana przez metode print()*/
void printData(const double d);