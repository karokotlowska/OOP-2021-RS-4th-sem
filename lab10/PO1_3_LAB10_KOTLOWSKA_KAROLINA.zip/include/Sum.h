#pragma once
#include "Data.h"

/*klasa przechowująca informacje o sumie wektora doubli nalezacego do klasy Sum*/
class Sum{
public:
/*@brief konstruktor klasy sum
@param sum - suma ktora ma byc wpisana do klasy*/
  Sum(const double sum);

  /*@brief metoda zwracająca wartosc sumy
  @return zwraca warosc sumy w wektorze*/
  double value()const;

  /*@brief operator () dodaje do sumy liczbę
  @param dod - liczba ktora ma byc dodana do sumy*/
  void operator()(const double dod);
private:
  double _sum;
};

/*@brief funkcja ktora sumuje dane z wektora
@param d1 - referencja na obiekt ktorego wektor ma byc sumowany
@return zwraca obiekt Sum*/
Sum sumData(const Data &d1);