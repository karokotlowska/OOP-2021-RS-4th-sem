#pragma once
#include "Data.h"
#include <functional>

/*klasa przechowujaca vektor obiektow klasy Data, jako kontener*/
class Table{
public:
/*@brief operator przeładowania += dodaje do kontenera nowy obiekt
@param referencja na obiekt, ktory ma byc dodany*/
  void operator+=(const Data &d1);

  /*parametr statyczny przechowujący informacje o minimalnej dlugosc wektora w kontenerze*/
  static int minRow;

  /*@brief metoda printująca dane z kontenera*/
  void print()const;

  /*@brief metoda sortująca konterner w zależnosci od kolumny
  @param k - kolumna na ktorej ma byc sortowanie
  @return zwraca *this*/
  const Table &sort(const int k);

  /*@brief metoda sortująca kontener za pomocą funkcji z maina
  @fun - funkcja ktora sortuje
  @return zwraca *this*/
  const Table &sortBy(std::function<bool(const Data& d1, const Data& d2)> fun);
  
private:
  std::vector<Data>_data;
};