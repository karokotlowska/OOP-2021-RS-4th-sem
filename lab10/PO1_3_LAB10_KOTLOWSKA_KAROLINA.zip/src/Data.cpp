#include "../include/Data.h"
#include <iostream>
#include <iomanip>
#include <algorithm>

Data::Data(const std::string str,const std::vector<double> vec):_str(str),_vec(vec){}

void Data::print()const{
  std::cout<<_str<<": ";
  std::for_each(_vec.begin(),_vec.end(),printData);
  std::cout<<"\n";
}


void printData(const double d){
  std::cout<<std::setw(6)<<d;
}


std::vector<double> Data::getVector()const{
  return _vec;
}

