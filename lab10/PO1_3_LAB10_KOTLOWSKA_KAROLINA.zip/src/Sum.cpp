#include "../include/Sum.h"
#include <iostream>
#include <algorithm>

Sum sumData(const Data &d1){
  double sum=0;
  std::vector<double>vec=d1.getVector();
  for_each(vec.begin(),vec.end(),[&](const double d)->void{sum+=d;});
  //ostatni parametr jako wyrazenie lambda, w kwadratowych nawiasach znak "&", aby funkcja miala dostęp do referencji na 'sum', zwraca void
  return Sum(sum);
}

Sum::Sum(const double sum):_sum(sum){}


double Sum::value()const{
  return _sum;
}

void Sum::operator()(const double dod){
  _sum+=dod;
}


