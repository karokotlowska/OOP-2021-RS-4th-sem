#include "../include/Table.h"
#include <iostream>
#include <algorithm>

int Table::minRow=1000; //zakladam ze wektor dat nie bedzie wiekszy niz 1000

void Table::operator+=(const Data &d1){
  _data.push_back(d1);
  if(minRow>d1.getVector().size()){
    minRow=d1.getVector().size();
  }
}

void Table::print()const{
  std::for_each(_data.begin(),_data.end(),[](const Data &d1)->void{d1.print();});
  //ostatni parametr wyrazenie lambda: brak wartosci w kwadratowym nawiasie - nie przekazuje zadnego parametru, zwraca void
  std::cout<<"\n";
}

const Table &Table::sort(const int k){
  if(minRow<=k){
    std::cout<<"Indeks "<<k<<" nieprawidlowy!\n";
    return *this;
  }
  std::sort(_data.begin(),_data.end(),[=](const Data &d1,const Data &d2)->bool{return d1.getVector()[k]<d2.getVector()[k];});
  //ostatni parametr wyrazenie lambda: wartosc '=' w kwadratowym nawiasie znaczy ze mamy dostep do zmiennej lokalnej - w tym przypadku k - czyli kolumna, zwraca bool
  return *this;
}

const Table &Table::sortBy(std::function<bool(const Data& d1, const Data& d2)> fun){
  std::sort(_data.begin(),_data.end(),fun);
  return *this;
}



