#pragma once
#include <iostream>
#include <string>
#include <vector>

//mnostwo warningow - sprawdzic czemu


/*konieczna klasa bazowa ponieważ nie mozna stworzyc wektora klasy ktora jest templatem*/
class Base{
  public:
    virtual ~Base()=default;
    virtual void Print()const=0;
};


template<typename T>
class Variable:public Base{ 
public:
  Variable(const std::string name,T value):_name(name),_value(value){}
  void Print()const override{
    std::cout<<_name<<": "<<_value<<"\n";
  }
  void SetValue(T value){
    _value=value;
  }
protected:
  T _value;
  std::string _name;
};

template<typename T>
class VariableWithUnits:public Variable<T>{
public:
  VariableWithUnits(const std::string name,T value,const std::string unit):Variable<T>(name,value),_unit(unit){}
  void Print()const override{
    //using Variable<std::string>_name;
    //using Variable<T>_value;
    std::cout<<this->_name<<": "<<this->_value<<"["<<_unit<<"]\n"; //zeby miec dostęp do danych szblonu klasy nalezy uzyc this->
  }
private:
  std::string _unit;
};

typedef Variable<double> VariableDouble;
typedef Variable<float> VariableFloat;
typedef Variable<int> VariableInt;
typedef Variable<char> VariableChar;
typedef Variable<bool> VariableBool;



class ArrayOfVariables{
public:
  ArrayOfVariables(const int k):_maxArraySize(k){}
  ~ArrayOfVariables(){
    for(unsigned i=0;i<_vec.size();i++){
      delete _vec[i];
    }
  }
  template<typename T>
  Variable<T>* CreateAndAdd (const std::string name, const T value);

   void Print()const{
    for(unsigned i=0;i<_vec.size();i++){
      _vec[i]->Print();
    }
  }
private: 
  int _maxArraySize;

  std::vector<Base*> _vec;
};

template<typename T>
Variable<T>* ArrayOfVariables::CreateAndAdd (const std::string name, const T value){
    if (_vec.size()>=(unsigned)_maxArraySize){
      Variable<T>* nowy=new Variable<T>(name,value);
      return nowy;
    }
    Variable<T>* nowy=new Variable<T>(name,value);
    _vec.push_back(nowy);
    return nowy;
  }

 

