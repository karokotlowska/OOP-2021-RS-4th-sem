#pragma once
#include <iostream>

/*@brief szablon klasy, ktory moze przyjmnowac dwa rozne typy, proste operacje jak dodawanie, mnożenie, zamiana miejscami, printowanie*/
template<typename T1,typename T2>
class PairOfNumbers{
public:
/*@brief konstruktor lokujący pierwszy podany paramtr na miejsce first, a drugi na miejsce second*/
  PairOfNumbers(T1 &val1,T2 &val2):first(val1),second(val2){}

/*@brief metoda zamieniająca first i second miejscami
@return zwraca obiekt, ktory został nowo utworzony z zamienionymi miejscami parametrów T1 i T2*/
  PairOfNumbers<T2,T1>Swapped(){
    PairOfNumbers<T2,T1> p(second,first);
    return p;
  }

/*@brief metoda printująca wartosci klasy*/
  void Print()const{
    std::cout<<"Print method: "<<first<<" "<<second<<"\n";
  }

/*@brief metoda dodajaca do kazdego z przechowywanych elementów pewną wartość; template T utworzony, ponieważ nie wiadomo jaki typ chcemy dodac*/
  template<typename T>
  void Add(T add){
    first+=add;
    second+=add;
  }

/*@brief metoda mnożąca kazdy z przechowywanych elementów przxez pewną wartość; template T utworzony, ponieważ nie wiadomo przez jaki typ chcemy pomnożyć*/
  template<typename T>
  void Scale(T scale){
    first=first*scale;
    second=second*scale;
  }

/*@brief metoda printująca informacje o tym ze obiekt nie jest const*/
  void Info(){
    std::cout<<"This is NON-const pair of numbers\n";
  }

  /*@brief metoda printująca informacje o tym ze obiekt jest const*/
  void Info()const{
    std::cout<<"This is const pair of numbers\n";
  }

  T1 &first;
  T2 &second;
};
