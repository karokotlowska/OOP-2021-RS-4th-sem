#pragma once
#include "PairOfNumbers.h"
#include <iostream>


/*@brief szablon klasy przyjmujący jakis typ*/
template<typename T>
class RangeArray{
public:
/*@brief konstruktor przyjmujący obiekt klasy PairOfNumbers jako parametr, ustawiajacy pierwszy parametr obiektu pair jako rozmiar tablicy RangeArray
@param obiekt klasy PairOfNumbers*/
  RangeArray(PairOfNumbers<int,T> &pair){
    _size=(int)(pair.second-pair.first);
    _ar=new T[_size];
  }
  
  /*@brief kontruktor kopiujący - potrzebny bo w mainie mamy funkcję, ktora nie operuje na referencji - czyli tworzy sobie nowy obiekt (kopię), więc bez tego kontruktora kopiujacego są problemy z pamięcią :) */
  RangeArray(const RangeArray &r):_size(r._size),_ar(new T[_size]){
    for(int i=0;i<_size;i++){
      _ar[i]=r._ar[i];
    }
  }

  /*@brief destruktor*/
  ~RangeArray(){
    delete []_ar;
  }

/*@brief metoda zwracająca rozmiar tablicy
@return zwraqca rozmiar tablicy*/
  int Size()const{
    return _size;
  }

/*@brief operator []
@return zwraca referencje na daną komórkę w tablicy ktorej szukamy*/
  T&operator[](int i){
    int k;
    if(i<0){
      k=_size+i;
    }
    else{
      k=i;
    }
    return _ar[k];
  }

/*@brief metoda analogiczna do operatora nawiasowego wyżej - wykorzystująca go
@return zwraca referencje na daną komórkę klasy, którą szukamy*/
  T& At(int i){
    return (*this)[i];
  }
private:
  int _size=0;
  T *_ar;
};