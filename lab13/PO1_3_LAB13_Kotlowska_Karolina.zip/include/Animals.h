#pragma once

#include <iostream>
#include "Animal.h"
#include <algorithm>
#include <functional>

class Sheep: public Animal{
public:
/*konstruktor*/
  explicit Sheep(const std::string &name):Animal(name){
    ostrzyzona=false;
  }
  ~Sheep(){
   if(ostrzyzona){
      std::cout<<"- Owca "<<name()<<" ostrzyzona wraca do zagrody\n";

    }
    else{
      std::cout<<"- Owca "<<name()<<" nieostrzyzona wraca do zagrody\n";
    }
  }
    /*metoda printująca dane o owcy, uzglednia czy owca jest ostrzyzona czy nie*/

  void print()const override{
    if(ostrzyzona){
      std::cout<<"- Owca "<<name()<<" ostrzyzona";

    }
    else{
      std::cout<<"- Owca "<<name()<<" nieostrzyzona";
    }
  }
 /*metoda ustawiająca ze owca jest ostrzyzona*/
  void shear(){
    ostrzyzona=true;
  }

private:
  bool ostrzyzona;
};


class Cow: public Animal{
public:
/*konstruktor*/
  explicit Cow(const std::string &name):Animal(name){}
  ~Cow(){
    std::cout<<"- Krowa "<<name()<<" wraca do obory\n";
  }
    /*metoda printująca dane o krowei*/
  void print()const override{
    std::cout<<"- Krowa "<<name();
  }
  
private:
};

class Horse: public Animal{
public:
/*konstruktor*/
  explicit Horse(const std::string &name):Animal(name){}
  ~Horse(){
    std::cout<<"- Kon "<<name()<<" wraca do stajni\n";
  }
  /*metoda printująca dane o koniu*/
  void print()const override{
    std::cout<<"- Kon "<<name();
  }

private:
};