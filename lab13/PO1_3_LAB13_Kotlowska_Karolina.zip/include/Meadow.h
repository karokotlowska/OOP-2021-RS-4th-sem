#pragma once
#include "Animals.h"
#include <memory>
#include <vector>
#include <string>
#include <utility>
#include <map>
#include <set>

class Meadow{
public:
/*metoda dodająca do wektora zwirzęta na łące*/
  void add(std::unique_ptr<Animal> animal){
    _vec.push_back(std::move(animal));
  }

/*metoda printująca łąkę*/
  void print(std::string s)const{
    std::cout<<"==="<<s<<"===\n";
    for(auto &s: _vec){
      s->print();
      std::cout<<"\n";
    }
  }

/*metoda licząca imiona owieczek*/
  void countNames(){
    std::map<std::string,int> _map;
    for(auto &s: _vec){
      _map[s->name()]++;
    }
     for(auto &s: _map){
      std::cout<<s.first<<": "<<s.second<<"\n";
    }
    /*std::set<std::string> _set;
    for(auto &s: _vec){
      _set.insert(s->name());
    }
    std::vector<int> _il;
    int i=0;
    for(auto &s: _set){

      for(unsigned j=1;j<_vec.size();j++){
        if(s==_vec[j]->name()){
          _il[i]++;
        }
      }
      i+=1;
    }*/

  }
/*metoda wyciągająca owieczki do wektora, zwracająca ten wektor*/
  std::vector<Sheep*> getSheepHerd(){
    std::vector<Sheep*> sheepherd;


for(auto &s: _vec){
  if(s->name()=="Bernadeta" ||s->name()=="Beata"){
        sheepherd.push_back(dynamic_cast<Sheep*>(s.get()));
      }
}
    //Sheep *sh;
   /* for(auto &s: _vec){
       if(s->name()=="Bernadeta" ||s->name()=="Beata")
    {

    }  */    //auto b=s.get();
      //if(sh==b){
        //sheepherd.push_back(s);
      //}
  
    return sheepherd;
  }

private:
  std::vector<std::unique_ptr<Animal>> _vec;
};